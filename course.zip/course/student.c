/**
 * @file student.c
 * @author Khai Khanna (khanna27@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief adding grades to the student type
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
/**
 * @brief checks if the student has a grade, adds for memory if it does.
 * 
 */
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    /**
     * @brief reallocates memory if the student has a grade or not so memory isnt wasted on nothing.
     * 
     */
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief calculates the average of the student by calculating the mean of their grades .
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**
 * @brief Prints the student with all the information gotten from the other functions, Prints their name, ID and grades along with average. IT is a report card or profile.
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief creates a list of random students by selecting random first and last naems and concenating them together.
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 /**
  * @brief assigns memory to house these students names.
  * 
  */
  Student *new_student = calloc(1, sizeof(Student));
/**
 * @brief the randomization process
 * 
 */
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
/**
 * @brief generates a random id based off of characters, used to create uniqueness for each student.
 * 
 */
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

/**
 * @brief calculates random grades for all students.
 * 
 */
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}