/**
 * @file course.h
 * @author Khai Khanna (khanna27@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief Typedef for course, creating the parameters that names can have 100 bits and course code can have 10.
 * Course will contains students and have an int for total students in course.
 * 
 */
 typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;
/**
 * @brief all the functions in course.c
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


