/**
 * @file course.c
 * @author Khai Khanna (khanna27@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
/**
 * @brief Enroll students puts a random amonunt of students into the struct typedef Course, and dedicates memory towards the total numbers of students.
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    /**
     * @brief realloc allocates unused memory to better store and create more efficient running of total students in course.
     * 
     */
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief Prints the course name and code in a list with total students in each course.
 * 
 * @param course 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief Calculates the the top student in each course by checking who has the highet average and returns that student.
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
  /**
   * @brief creating variables
   * Student_average is the average of the students and max_average is to discern the highest average among the students.
   * 
   */
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  /**
   * @brief Checks which student has the highest average and creates a new vairable to store that, if it is passed the new student gets to hold that title.
   * 
   * @param i 
   */
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief Finds who is passing the course by seeing which student has a grade higher than 50%. If they pass that case, they are submitted to be returned.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  /**
   * @brief Checks who is passing by indexing the students from total students.
   * 
   */
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
    /**
   * @brief creats a passing array with memory dedicated to house the size of students.
   * 
   */
  passing = calloc(count, sizeof(Student));
  /**
   * @brief changes the students in the course with the passing students.
   * 
   */
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}